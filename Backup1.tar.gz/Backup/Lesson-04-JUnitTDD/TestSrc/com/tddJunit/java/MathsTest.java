package com.tddJunit.java;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class MathsTest {

	//Comment-1: private Maths classundertest;	

	@Before
	public void setUp() throws Exception {

		//comment-2: classundertest = new Maths();

	}

	@Test
	public void testAdd() {
		//comment-3 : fail("Not yet implemented");

		/* comment-4:	long result = 10+2;
assertEquals(result, classundertest.add(10,2)); */

	}

	@Test
	public void testSubtract() {
	//comment-5: fail("Not yet implemented");
	/* comment-6: long result = 10-2;
		assertEquals(result, classundertest.subtract(10,2));*/	

	}

}
